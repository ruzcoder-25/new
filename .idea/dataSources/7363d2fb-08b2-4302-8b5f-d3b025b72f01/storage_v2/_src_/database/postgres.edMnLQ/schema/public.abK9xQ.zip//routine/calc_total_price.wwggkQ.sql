create function calc_total_price() returns trigger
    language plpgsql
as
$$
BEGIN
    SELECT price INTO NEW.TOTAL_price FROM products WHERE id = NEW.product_id;
    NEW.total_price := NEW.total_price * NEW.quantity;
    RETURN NEW;
END;
$$;

alter function calc_total_price() owner to postgres;

