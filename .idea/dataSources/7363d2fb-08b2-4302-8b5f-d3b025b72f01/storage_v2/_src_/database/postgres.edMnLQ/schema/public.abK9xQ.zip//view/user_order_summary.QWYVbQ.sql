create view user_order_summary(name, order_count, total_spent) as
SELECT u.name,
       count(o.id)        AS order_count,
       sum(o.total_price) AS total_spent
FROM users u
         JOIN orders o ON u.id = o.user_id
GROUP BY u.name;

alter table user_order_summary
    owner to postgres;

