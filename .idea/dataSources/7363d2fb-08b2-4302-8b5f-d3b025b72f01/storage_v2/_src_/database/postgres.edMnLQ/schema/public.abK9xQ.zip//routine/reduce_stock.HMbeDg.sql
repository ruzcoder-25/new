create function reduce_stock() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.quantity > (SELECT stock FROM products WHERE id = NEW.product_id) THEN
        RAISE EXCEPTION 'Yetarli zaxira yuq';
    END IF;
    UPDATE products SET stock = stock - NEW.quantity WHERE id = NEW.product_id;
    RETURN NEW;
END;
$$;

alter function reduce_stock() owner to postgres;

